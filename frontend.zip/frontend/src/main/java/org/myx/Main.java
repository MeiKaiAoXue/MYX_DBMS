package org.myx;

import org.myx.processing.Table;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello frontend!");
    }
}