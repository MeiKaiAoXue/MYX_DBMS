//import org.myx.fileIo.Logging;
//
//import java.io.IOException;
//
//public class TestLogging {
//    public void testLog() {
//        try {
//            Logging.log("This is a test log message");
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//}
