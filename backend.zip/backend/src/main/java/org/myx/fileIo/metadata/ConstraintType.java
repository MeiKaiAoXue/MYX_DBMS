package org.myx.fileIo.metadata;

public enum ConstraintType {
    PRIMARY_KEY,
    NOT_NULL,
    UNIQUE,
    CHECK,
    DEFAULT,
    REFERENCES,
    FOREIGN_KEY
}
